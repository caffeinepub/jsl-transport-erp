import { useState, useEffect } from "react";
import { backend } from "../declarations/backend";

export default function DieselBill() {
  const [billNo, setBillNo] = useState("");
  const [data, setData] = useState([]);
  const [selected, setSelected] = useState([]);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const res = await backend.getDieselEntries();
    setData(res.filter(d => d.status === "PENDING"));
  };

  const toggle = (slip) => {
    if (selected.includes(slip)) {
      setSelected(selected.filter(s => s !== slip));
    } else {
      setSelected([...selected, slip]);
    }
  };

  const save = async () => {
    await backend.createDieselBill(billNo, selected);
    alert("Bill linked");
    load();
  };

  return (
    <div>
      <h2>Diesel Bill</h2>

      <input
        placeholder="Bill No"
        value={billNo}
        onChange={(e) => setBillNo(e.target.value)}
      />

      <table>
        <thead>
          <tr>
            <th>Select</th>
            <th>Slip</th>
            <th>Vehicle</th>
            <th>Amount</th>
          </tr>
        </thead>

        <tbody>
          {data.map((d, i) => (
            <tr key={i}>
              <td>
                <input
                  type="checkbox"
                  onChange={() => toggle(d.slipNo)}
                />
              </td>
              <td>{d.slipNo}</td>
              <td>{d.vehicleNo}</td>
              <td>{d.amount}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <button onClick={save}>Save Bill</button>
    </div>
  );
}

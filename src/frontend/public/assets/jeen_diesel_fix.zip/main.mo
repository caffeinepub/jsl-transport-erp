// --- Diesel System Added ---

type DieselEntry = {
  id: Nat;
  tripId: Nat;
  vehicleNo: Text;
  date: Text;
  qty: Float;
  amount: Float;
  slipNo: Text;
  pump: Text;
  status: Text; // "PENDING" | "BILLED"
  billNo: ?Text;
};

stable var dieselEntries: [DieselEntry] = [];
stable var dieselId: Nat = 0;

// Add this inside createTrip()
// AUTO CREATE DIESEL ENTRY
// (Integrate variables as per your existing code)

// Query
public query func getDieselEntries() : async [DieselEntry] {
  return dieselEntries;
};

// Bill mapping
public func createDieselBill(billNo: Text, slipNos: [Text]) : async () {

  var updated : [DieselEntry] = [];

  for (d in dieselEntries.vals()) {

    if (Array.find<Text>(slipNos, func(x) { x == d.slipNo }) != null) {
      updated := Array.append(updated, [{
        id = d.id;
        tripId = d.tripId;
        vehicleNo = d.vehicleNo;
        date = d.date;
        qty = d.qty;
        amount = d.amount;
        slipNo = d.slipNo;
        pump = d.pump;
        status = "BILLED";
        billNo = ?billNo;
      }]);
    } else {
      updated := Array.append(updated, [d]);
    };
  };

  dieselEntries := updated;
};

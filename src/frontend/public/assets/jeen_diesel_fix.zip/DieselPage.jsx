import { useEffect, useState } from "react";
import { backend } from "../declarations/backend";

export default function DieselPage() {
  const [data, setData] = useState([]);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const res = await backend.getDieselEntries();
    setData(res);
  };

  return (
    <div>
      <h2>Diesel Entries</h2>
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Vehicle</th>
            <th>Slip</th>
            <th>Qty</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Bill</th>
          </tr>
        </thead>
        <tbody>
          {data.map((d, i) => (
            <tr key={i}>
              <td>{d.date}</td>
              <td>{d.vehicleNo}</td>
              <td>{d.slipNo}</td>
              <td>{d.qty}</td>
              <td>{d.amount}</td>
              <td>{d.status}</td>
              <td>{d.billNo || "-"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
